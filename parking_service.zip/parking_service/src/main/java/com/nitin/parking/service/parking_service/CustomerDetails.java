package com.nitin.parking.service.parking_service;

public class CustomerDetails {
	
	String ownerName, carNo, time;
	Long phoneNo;
	int floor, section, compartment;
	
	
	public CustomerDetails(String ownerName, String carNo, String time, long phoneNo) {
		super();
		this.ownerName = ownerName;
		this.carNo = carNo;
		this.time = time;
		this.phoneNo = phoneNo;
	}

	public String getTime() {
		return time;
	}



	public Long getPhoneNo() {
		return phoneNo;
	}




	public int getSection() {
		return section;
	}



	public void setFloor(int floor) {
		this.floor = floor;
	}


	public void setSection(int section) {
		this.section = section;
	}


	public void setCompartment(int compartment) {
		this.compartment = compartment;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public String getCarNo() {
		return carNo;
	}


	public int getFloor() {
		return floor;
	}


	public int getCompartment() {
		return compartment;
	}

	@Override
	public String toString() {
		return "CustomerDetails [ownerName=" + ownerName + ", carNo=" + carNo + ", time=" + time + ", phoneNo="
				+ phoneNo + ", floor=" + floor + ", section=" + section + ", compartment=" + compartment + "]";
	}
}
