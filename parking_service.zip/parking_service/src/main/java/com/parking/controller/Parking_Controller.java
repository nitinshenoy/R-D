package com.parking.controller;

import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.nitin.parking.service.parking_service.CustomerDetails;

public class Parking_Controller {
	
	final int size = 160;
	TreeMap<Integer,CustomerDetails> parkingMap = new TreeMap<Integer,CustomerDetails>();  
	SortedSet<Integer> available = new TreeSet<Integer>();
	SortedSet<Integer> filled = new TreeSet<Integer>();
	
	public Parking_Controller() {
		for(int index=1;index<161; index++) {
			available.add(index);
		}
	}
	
	public void addCar(CustomerDetails c) {
		
		if(parkingMap.size()>=160) {
			throw new RuntimeException("Parking Full");
		}
		int key = available.first();
		parkingMap.put(key, c);
		available.remove(key);
		filled.add(key);
		c = findSlot(key, c);
	}
	
	public TreeMap<Integer, CustomerDetails> retrieveCars() {
		return parkingMap;
	}
	
	public void remoceCar(CustomerDetails c) {
		
		if(parkingMap.containsValue(c)) {
			for( Integer index : parkingMap.keySet()) {
				if(c == parkingMap.get(index))
				{
					parkingMap.remove(index);
					filled.remove(index);
					available.add(index);
					return;
				}
			}
		}
		throw new RuntimeException("The car is left");
	}
	
	public CustomerDetails findSlot(int index, CustomerDetails c)
	{
		int count = 1;
		while(count< 5) {	
		if(index>=1*count && index<=40*count)
		{
			c.setFloor(count);
			if(index< (40*(count-1) + 11))
			{
				c.setSection(1);
				c.setCompartment(index%10);
				return c;
			}
			else if(index < (40*(count-1) + 21))
			{
				c.setSection(2);
				c.setCompartment(index%10);
				return c;
			}
			else if(index < (40*(count-1) + 31))
			{
				c.setSection(3);
				c.setCompartment(index%10);
				return c;
			}
			else
			{
				c.setSection(4);
				c.setCompartment(index%10);
				return c;
			}
		}
		count++;
		}
		throw new RuntimeException("Invalid Key");
	}
	
	
	public static void main(String[] args)
	{
		Parking_Controller p = new Parking_Controller();
		CustomerDetails c1 = new CustomerDetails("Goku", "12355gg", "9:9", 7777777L);
		p.addCar(c1);
		CustomerDetails c2 = new CustomerDetails("Vegeta", "1444ff", "8:8", 7777777L);
		p.addCar(c2);
		CustomerDetails c3 = new CustomerDetails("Deadpool", "1352rr", "7:17", 7777777L);
		p.addCar(c3);
		CustomerDetails c4 = new CustomerDetails("Freiza", "111dd", "1:10", 7777777L);
		p.addCar(c4);
		CustomerDetails c5 = new CustomerDetails("GOT", "17788jj", "0:10", 7777777L);
		p.addCar(c5);
		System.out.println("5 Cars added\n"+p.retrieveCars());
		
		p.remoceCar(c2);
		System.out.println("Car 2 removed\n"+p.retrieveCars());
		
		CustomerDetails c6 = new CustomerDetails("Nitin", "133344ee", "4:10", 6548654L);
		p.addCar(c6);
		System.out.println("When the Car 6 added (position 2)\n"+p.retrieveCars());
	}
}
